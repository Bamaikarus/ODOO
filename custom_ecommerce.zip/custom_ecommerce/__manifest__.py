{
    'name': 'Custom Ecommerce',
    'version': '1.0',
    'category': 'Website',
    'depends': ['website_sale'],
    'data': [
    ],
    'assets': {
        'web.assets_frontend': [
            '/custom_ecommerce/static/src/js/custom.js',
        ],
    },
    'installable': True,
    'application': False,
}
