/** @odoo-module */

(function () {
    window.addEventListener("message", function(event) {
        const config = event.data;
        console.log(config);
        

        if (!config || typeof config !== 'object') return;

       

        $.ajax({
            url: '/test',
            type: 'GET',
            success: function(response) {
                console.log(response);
            },
            error: function(err) {
                console.log(err);
            }
        })
    });
})();
